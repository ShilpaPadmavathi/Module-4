package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GoogleStepDefinition {
	
	private WebDriver driver;
	private WebElement searchBox;
	
	@Given("^User is on Google Home Page$")
	public void user_is_on_Google_Home_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\pagorant\\Downloads/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://www.google.com");
		Thread.sleep(5000);
	 
	}

	@When("^User Finds Search Box$")
	public void user_Finds_Search_Box() throws Throwable {
		searchBox=driver.findElement(By.xpath("//input[@name='q']"));
	    
	}

	@Then("^it enters a search keyword$")
	public void it_enters_a_search_keyword() throws Throwable {
		searchBox.sendKeys("Anushka Sharma Marriage Pics");
		searchBox.submit();
		Thread.sleep(10000);
		driver.quit();
	    
	}


}
