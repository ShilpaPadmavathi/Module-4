package com.recipe;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/resources/Recipe/Recipe.feature",glue="com.recipe") 
public class TestRunner {

}
